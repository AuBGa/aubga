package com.aubga.bytecode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BytecodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(BytecodeApplication.class, args);
	}

}
